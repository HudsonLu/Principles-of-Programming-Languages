import os
import sys
import math

"""
Hudson Xingcheng Lu              40254326
COMP 348 
Assignment 2 

Database.txt used

shape
rhombus 10 20
circle 2
ellipse 2 4
shape
ellipse -1 4
rhombus 40 10
ellipse 2 4


"""    

################### class Shape
class Shape:
    shape_count = 0

    def __init__(self):
        Shape.shape_count += 1
        self.id = Shape.shape_count
    def __str__(self):
        return self.__class__.__name__

    def print(self):
        shape_name = self.__class__.__name__
        perimeter = self.perimeter()
        area = self.area()
        eccentricity = self.eccentricity()
        side = self.side()
        inradius = self.inradius()
###########################
        if perimeter is None:
            perimeter_str = "undefined"
        else:
            perimeter_value = float(perimeter)
            if perimeter_value.is_integer():
                perimeter_str = str(int(perimeter_value))
            else:
                perimeter_str = f"{perimeter_value:.5f}"
###########################
        if area is None:
            area_str = "undefined"
            
        else:
            area_value = float(area)
            if area_value.is_integer():
                area_str = str(int(area_value))
            else:
                area_str = f"{area_value:.5f}"
##########################

        if (eccentricity is None) :
            eccentricity_str = "  "
            if side is None:
                side_str = " "
                if inradius is None:
                    inradius_str = " "  
                    print(f"{self.id}: {shape_name}, perimeter: {perimeter_str}, area: {area_str}")
        else:
            eccentricity_value = float(eccentricity)
            if eccentricity_value.is_integer():
                eccentricity_str = str(int(eccentricity_value))
            else:
                eccentricity_str = f"{eccentricity_value:.5f}"
                print(f"{self.id}: {shape_name}, perimeter: {perimeter_str}, area: {area_str}, eccentricity: {eccentricity_str}")
#########################
        if side is None:
            side_str = " "

        else:
            side_value = float(side)
            if side_value.is_integer():
                side_str = str(int(side_value))
            else:
                side_str = f"{side_value:.5f}"
####################            
        if inradius is None:
            inradius_str = " "  
        else:
            inradius_value = float(inradius)
            if inradius_value.is_integer():
                inradius_str = str(int(inradius_value))
            else:
                inradius_str = f"{inradius_value:.5f}"
            print(f"{self.id}: {shape_name}, perimeter: {perimeter_str}, area: {area_str}, side: {side_str}, inradius: {inradius_str}")
    
              
    def perimeter(self):
        return None

    def area(self):
        return None

    def eccentricity(self):
        return None
    def inradius(self):
        return None
    def side(self):
        return None

    
    def __eq__(self, other):
        if isinstance(other, self.__class__):
            return vars(self) == vars(other)
        return False

######################################### class Circle
class Circle(Shape):
    def __init__(self, radius):
        super().__init__()
        self.radius = radius

    def perimeter(self):
        return 2 * math.pi * self.radius

    def area(self):
        return math.pi * self.radius ** 2
    def __str__(self):
        return f"circle {self.radius}"
    
######################################### class Ellipse

class Ellipse(Shape):
    def __init__(self, a, b):
        super().__init__()
        self.a = max(a, b)
        self.b = min(a, b)
    def __str__(self):
        return f"ellipse {self.a} {self.b}"
    def perimeter(self):
        return None

    def area(self):
        return math.pi * self.a * self.b

    def eccentricity(self):
        return math.sqrt(self.a ** 2 - self.b ** 2)
######################################### class Rhombus

class Rhombus(Shape):
    def __init__(self, p, q):
        super().__init__()
        self.p = p
        self.q = q
    def __str__(self):
        return f"rhombus {self.p} {self.q}"
    def perimeter(self):
        return 2 * math.sqrt(self.p ** 2 + self.q ** 2)

    def area(self):
        return 0.5 * self.p * self.q

    def side(self):
        return math.sqrt(self.p ** 2 + self.q ** 2) / 2

    def inradius(self):
        return self.p * (self.q / (2 * math.sqrt(self.p ** 2 + self.q ** 2)))
    
######################################### Shape Database

class ShapeDB:
    def __init__(self):
        self.shapes = []
######## 1
    def load_database(self, filename):
        try:
            print(f"Processing {filename}...")
            with open(filename, 'r') as file:
                lines = file.readlines()

            count = 0
            error_count = 0
            for line in lines:
                count += 1
                line = line.strip()
                if line:
                    shape_info = line.split()
                    shape_name = shape_info[0].lower()
                    shape_params = list(map(float, shape_info[1:]))

                    try:
                        if shape_name == "circle" and len(shape_params) == 1:
                            radius = shape_params[0]
                            shape = Circle(radius)
                        elif shape_name == "ellipse" and len(shape_params) == 2:
                            a, b = shape_params
                            if a <= 0 or b <= 0:
                                raise ValueError("Invalid dimensions for Ellipse")
                            shape = Ellipse(a, b)
                        elif shape_name == "rhombus" and len(shape_params) == 2:
                            p, q = shape_params
                            shape = Rhombus(p, q)
                        elif shape_name == "shape" and len(shape_params) == 0:
                            shape = Shape()
                        else:
                            raise ValueError(f"Invalid {shape_name.capitalize()}")

                        if shape not in self.shapes:
                            self.shapes.append(shape)
                    except Exception as e:
                        print(f"Error: {str(e)} on line {count}: {line}")
                        error_count += 1

            print(f"Processed {count} row(s), {len(self.shapes)} shape(s) added, {error_count} error(s).")
        except Exception as e:
            print(f"An error occurred while processing the file: {str(e)}")

######## 2
    def convert_to_set(self):
        unique_shapes = []
        shape_params = set()

        for shape in self.shapes:
            shape_tuple = tuple(str(shape).split())

            if shape_tuple not in shape_params:
                shape_params.add(shape_tuple)
                unique_shapes.append(shape)

        self.shapes = unique_shapes
        print("Converted the current multi-set to a set.")     
######## 3
    def save_database(self, filename):
        try:
            with open(filename, 'w') as file:
                for shape in self.shapes:
                    if isinstance(shape, Shape):
                        if not isinstance(shape, Circle) and not isinstance(shape, Ellipse) and not isinstance(shape, Rhombus):
                            file.write("shape\n")
                    if isinstance(shape, Circle):
                        file.write(f"circle {int(shape.radius)}\n")
                    elif isinstance(shape, Ellipse):
                        file.write(f"ellipse {int(shape.a)} {int(shape.b)}\n")
                    elif isinstance(shape, Rhombus):
                        file.write(f"rhombus {int(shape.p)} {int(shape.q)}\n")

            print(f"Saved the database to {filename}.")
        except Exception as e:
            print(f"An error occurred while saving the database: {str(e)}")
            
######## 4
    def print_database(self):
        for shape in self.shapes:
            shape.print()
######## 5
    def summary(self):
        shape_counts = {}
        for shape in self.shapes:
            shape_name = shape.__class__.__name__
            shape_counts[shape_name] = shape_counts.get(shape_name, 0) + 1

        for shape_name, count in sorted(shape_counts.items()):
            print(f"{shape_name}(s): {count}")
        print(f"Shape(s): {len(self.shapes)}")
######## 6
    def details(self):
        for shape in self.shapes:
            if isinstance(shape, Shape):
                if not isinstance(shape, Circle) and not isinstance(shape, Ellipse) and not isinstance(shape, Rhombus):
                    print("shape")
            if isinstance(shape, Circle):
                print(f"circle {int(shape.radius)}")
            elif isinstance(shape, Ellipse):
                print(f"ellipse {int(shape.a)} {int(shape.b)}")
            elif isinstance(shape, Rhombus):
                print(f"rhombus {int(shape.p)} {int(shape.q)}")


######################################### main method

def main():
    db = ShapeDB()
    while True:
        print("""

Please write the command you wish to have.
-------------------------------------------
LOAD <filename>
TOSET
SAVE <filename>
PRINT
SUMMARY
DETAILS
QUIT
-------------------------------------------
        """)
        command = input("Enter a command: ")
        parts = command.split()
        operation = parts[0].upper()

        if operation == "LOAD":
            if len(parts) < 2:
                print("Please provide a filename.")
            else:
                filename = parts[1]
                db.load_database(filename)
        elif operation == "TOSET":
            db.convert_to_set()
        elif operation == "SAVE":
            if len(parts) < 2:
                print("Please provide a filename.")
            else:
                filename = parts[1]
                db.save_database(filename)
        elif operation == "PRINT":
            db.print_database()
        elif operation == "SUMMARY":
            db.summary()
        elif operation == "DETAILS":
            db.details()
        elif operation == "QUIT":
            print("Thank you for using this platform!")
            sys.exit("Exiting the program.")
        else:
            print("Invalid command. Please try again.")
            
###########################        

print("--Welcome to your multi-paradigm application!--------------")
print("--It processes some databases of shapes in text format. ---")
if __name__ == "__main__":
    main()



    
